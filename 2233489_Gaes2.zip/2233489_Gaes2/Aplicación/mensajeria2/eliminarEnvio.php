<?php
include("conexion.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM orden WHERE id = $id";
    $result = mysqli_query($conexion, $query);

    if (!$result) {
        die("Query Failed");
    }

    $_SESSION['message'] = 'Paciente eliminado';
    $_SESSION['message_type'] = 'danger';
    header("Location: envios.php");
}


?>