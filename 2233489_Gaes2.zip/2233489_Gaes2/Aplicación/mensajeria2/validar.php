
<?php

$documento=$_POST['documento'];
$password=$_POST['password'];

session_start();


include ('conexion.php');

        if($documento==""){
            echo "El campo del documento está vacío";
            }
            
  
if(isset($_GET['cerrar_sesion'])){
    session_unset();
    session_destroy();
}

$consulta="SELECT*from usuarios where documento=$documento and password=$password";
$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_fetch_array($resultado);


if($filas['id_rol']==1){
    header("location: vistaAdmin.php");
} else if($filas['id_rol']==2){
    header("location: vistaMensajero.php");
}
else{ 
    ?>
    <?php 
include('index.php');

header("location: index.php");
echo "ERROR HHHHHH";
  
    ?>
    
    <h1>ERROR EN LA AUTENTICACIÓN</h1>

<?php
}

mysqli_free_result($resultado);
mysqli_close($conexion);
?>