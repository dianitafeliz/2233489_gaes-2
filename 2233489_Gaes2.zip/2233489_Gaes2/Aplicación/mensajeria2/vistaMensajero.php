<?php
include("conexion.php")
?>

<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <script src="alertas.js"></script>

  
  
  <title>Envios</title>
</head>
<body class="bg-gray-100 text-gray-800">

<nav class="flex py-4 bg-indigo-500 text-white">
    <div class="w-1/2 px-12 mr-auto">
        <p class="text-2xl font-bold">Bienvenido Mensajero</p>
    </div>

    <ul class="w-1/2 px-16 ml-auto flex justify-end pt-1">
        <li class="mx-6">
            <a href="index.php" class="font-semibold hover:bg-indigo-700 py-3 px-4 rounded-md">Logout</a>
         </li>   
         
    </ul>

</nav>

<div class="flex h-screen">
<div class="border-r p-6 border-blue-200 w-64">
    <h6 class="flex-grow text-2xl font-bold mb-8">MENÚ </h6>
    <ul>
        
       

        <li class="flex mb-8">
            <div class="flex bg-white shadow-sm p-3 mr-3 rounded-lg">
                <img class="mr-3" src="icons/entrega-de-comida.png " width="30%">
                <span><a href="vistaMensajero.php">ENVIOS</a></span>
            </div>    
        </li>

    </ul>
</div>

<div class="p-6"><br>
    
<div class= "col-md-12 mx-auto  ">
        <table id="myTable" class="display">
            <thead>
                <tr>
                <th>id</th>
                <th width="12%">Fecha</th>
                <th>Hora</th>
                <th>Dir Recogida</th>
                <th>Dir Entrega</th>
                <th>Descripción</th>
                <th width="15%">Persona recibe</th>
                <th>Telefono</th>
                <th>Valor del envio</th>
                
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM orden";
                $pintar =  mysqli_query($conexion, $query);

                while ($row = mysqli_fetch_array($pintar)) { ?>
                    <tr>
                <td><?php echo $row["id"] ?></td>
                <td><?php echo $row["fecha"] ?></td>
                <td><?php echo $row["hora"] ?></td>
                <td><?php echo $row["recogida"] ?></td>
                <td><?php echo $row["entrega"] ?></td>
                <td><?php echo $row["descripcion"] ?></td>
                <td><?php echo $row["nombreR"] ?></td>
                <td><?php echo $row["telefonoR"] ?></td>
                <td><?php echo $row["valor"] ?></td>
                
                    </tr>
                <?php } ?>
                
                
            
            </tbody>

        </table>

      
    </div>
</div>

</div>