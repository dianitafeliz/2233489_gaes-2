<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.1/tailwind.min.css">
  <title>VistaAdmin</title>
</head>
<body class="bg-gray-100 text-gray-800">

<nav class="flex py-5 bg-indigo-500 text-white">
    <div class="w-1/2 px-12 mr-auto">
        <p class="text-2xl font-bold">Bienvenido Administrador</p>
    </div>

    <ul class="w-1/2 px-16 ml-auto flex justify-end pt-1">
        <li class="mx-6">
            <a href="index.php" class="font-semibold hover:bg-indigo-700 py-3 px-4 rounded-md">Logout</a>
         </li>   
         
    </ul>

</nav>

<div class="flex h-screen">
<div class="border-r p-6 border-blue-200 w-64">
    <h6 class="flex-grow text-2xl font-bold mb-8">MENÚ </h6>
    <ul>
        <li class="flex mb-8">
            <div class="flex bg-white shadow-sm p-3 mr-3 rounded-lg">
                <img class="mr-3" src="icons/opinion-del-cliente.png " width="30%">
                <span><a href="clientes.php">CLIENTES</a></span>
                <a href=""></a>
            </div>    
        </li>
        <li class="flex mb-8">
            <div class="flex bg-white shadow-sm p-3 mr-3 rounded-lg">
                <img class="mr-3" src="icons/operador.png " width="30%">
                <span><a href="mensajeros.php">MENSAJEROS</a></span>
            </div>    
        </li>

        <li class="flex mb-8">
            <div class="flex bg-white shadow-sm p-3 mr-3 rounded-lg">
                <img class="mr-3" src="icons/entrega-de-comida.png " width="30%">
                <span><a href="envios.php">ENVIOS</a></span>
            </div>    
        </li>
    </ul>
</div>

<div class="p-6">
    
    <img src="img/fondo.png" alt="" srcset="">
</div>

</div>








</body>
</html>