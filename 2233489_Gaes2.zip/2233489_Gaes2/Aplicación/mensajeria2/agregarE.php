

<?php

require ("conexion.php");

        $id ='';
        $fecha =$_POST['fecha'];
        $hora = $_POST['hora'];
        $recogida = $_POST['recogida'];
        $entrega = $_POST['entrega'];
        $descripcion = $_POST['descripcion'];
        $nombre = $_POST['nombre'];
        $telefono = $_POST['telefono'];
        $valor = $_POST['valor'];
       
      

$insertar = ("insert into orden values ('$id','$fecha','$hora', '$recogida', '$entrega','$descripcion','$nombre','$telefono','$valor')");
// estamos ejecutando el query para saber si se conecta a la base de datos
$query = mysqli_query($conexion, $insertar);

//if para saber si se conectó

if ($query) {
    $_SESSION['message'] = 'Paciente eliminado';
    $_SESSION['message_type'] = 'danger';
    header("Location: envios.php");
    # code...
}else{
    echo "conexion incorrecta";
}

// ahora se linkea el archivo de la conexionSQL

?>