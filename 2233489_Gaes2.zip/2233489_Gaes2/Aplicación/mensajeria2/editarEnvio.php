<?php

include("conexion.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM orden WHERE id = $id";
    $result = mysqli_query($conexion, $query);

    if (mysqli_num_rows($result) == 1) {
       $row = mysqli_fetch_array($result);
       $id = $row['id'];
       $fecha = $row['fecha'];
       $hora = $row['hora'];
       $recogida = $row['recogida'];
       $entrega = $row['entrega'];
       $descripcion = $row['descripcion'];
       $nombre = $row['nombreR'];
       $telefono = $row['telefonoR'];
       $valor = $row['valor'];
    }

    if (isset($_POST['update'])){
        $id =$_GET['id'];
        $fecha =$_POST['fecha'];
        $hora = $_POST['hora'];
        $recogida = $_POST['recogida'];
        $entrega = $_POST['entrega'];
        $descripcion = $_POST['descripcion'];
        $nombre = $_POST['nombre'];
        $telefono = $_POST['telefono'];
        $valor = $_POST['valor'];


        $query = "UPDATE orden set  id='$id',fecha='$fecha', hora ='$hora', recogida='$recogida', entrega='$entrega', descripcion='$descripcion', nombreR='$nombre', telefonoR='$telefono', valor='$valor' WHERE id = $id";
        mysqli_query($conexion, $query);
        header("Location:envios.php");
    }

}?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>editar envio</title>
</head>
<body>
<div class="container p-4">
    <div class="row">
<div class="col-md-4 mx-auto">
    <div class="card card-body">
        <div class="card card-header">EDITAR ENVIOS</div>
    <form action="editarEnvio.php?id=<?php echo $_GET['id'];?>" method="POST">
    
    <div class="form-group">
        <input type="date" name="fecha" value="<?php echo $fecha?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="time" name="hora" value="<?php echo $hora?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="recogida" value="<?php echo $recogida?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="entrega" value="<?php echo $entrega?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="descripcion" value="<?php echo $descripcion?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="nombre" value="<?php echo $nombre?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="number" name="telefono" value="<?php echo $telefono?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="number" name="valor" value="<?php echo $valor?>" class="form-control">
    </div>

    <br><button onclick="return alert ('Envio editado con exito')" class="btn btn-success" name="update">
    Actualizar
    </button>
    </form>
    </div>
</div>

    
    </div>
</div>

</body>
</html>