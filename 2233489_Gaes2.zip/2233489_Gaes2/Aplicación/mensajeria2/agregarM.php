

<?php

require ("conexion.php");


        $documento =$_POST['documento'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $correo = $_POST['correo'];
        $direccion = $_POST['direccion'];
        $telefono = $_POST['telefono'];
       
        $password = $_POST['password'];

echo $documento."<br>";
echo $nombre."<br>";
echo $apellido."<br>";
echo $correo."<br>";
echo $direccion."<br>";
echo $telefono."<br>";
echo $password."<br>";


$insertar = ("insert into usuarios values ('$documento','$nombre', '$apellido', '$correo','$direccion','$telefono','2','$password')");
// estamos ejecutando el query para saber si se conecta a la base de datos
$query = mysqli_query($conexion, $insertar);

//if para saber si se conectó

if ($query) {
    $_SESSION['message'] = 'Paciente eliminado';
    $_SESSION['message_type'] = 'danger';
    header("Location: Mensajeros.php");
    # code...
}else{
    echo "conexion incorrecta";
}

// ahora se linkea el archivo de la conexionSQL

?>