function validar(){
    documento = documento.getElementById("documento").value;
    password = documento.getElementById("password").value;
    console.log(documento);
    console.log(password);

    if(documento.length==0){
        alert("Debe ingresar su documento")
    }

    if(password.length==0){
        alert("Debe ingresar su contraseña")
    }
}