<?php
include("conexion.php");

if (isset($_GET['documento'])) {
    $documento = $_GET['documento'];
    $query = "DELETE FROM usuarios WHERE documento = $documento";
    $result = mysqli_query($conexion, $query);

    if (!$result) {
        die("Query Failed");
    }

    $_SESSION['message'] = 'Paciente eliminado';
    $_SESSION['message_type'] = 'danger';
    header("Location: mensajeros.php");
}


?>