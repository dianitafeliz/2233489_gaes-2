<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.1/tailwind.min.css">
  <title>ServiEnvios</title>
</head>
<body class="bg-gray-100 text-gray-800">

<nav class="flex py-5 bg-indigo-500 text-white">
    <div class="w-1/2 px-12 mr-auto">
        <p class="text-2xl font-bold">SERVIENVIOS GAES 4 2233489</p>
    </div>

    <ul class="w-1/2 px-16 ml-auto flex justify-end pt-1">
        <li class="mx-6">
            <a href="index.php" class="font-semibold hover:bg-indigo-700 py-3 px-4 rounded-md">Login</a>
         </li>   
         <li>   
            <a href="registro.php" class="font-semibold border-2 border-white py-2 px-4 rounded-md hover:bg-white hover:text-indigo-700">Registrarse</a>
        </li>
    </ul>

</nav>

<div class="block mx-auto my-12 p-8 bg-white w-1/3 border-gray-200 rounded-lg shadow-lg">
<h1 class="text-3xl text-center font-bold">Registro</h1>
<form action="agregarUsuario.php" class="mt-4" method="POST">
    

    <input type="number" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Documento de identidad' id='documento' name='documento'>
    <input type="text" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Nombres' id='nombre' name='nombre'>
    <input type="text" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Apellidos' id='apellido' name='apellido'>
    <input type="email" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Correo electronico' id='correo' name='correo'>
    <input type="text" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Dirección' id='direccion' name='direccion'>
    <input type="text" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Telefono' id='telefono' name='telefono'>
    <input type="text" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Tipo de usuario' id='rol' name='rol'>

    <input type="password" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Password' id='password' name='password'>
    <input type="password" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder='Confirmar Password' id='pasword_confirmation' name='pasword_confirmation'>


   

    <button type="submit" class="rounded-md bg-indigo-500 w-full text-lg text-white font-semibold p-2 my-3 hover:bg-indigo-600">Enviar</button>



</form>

</div>







</body>
</html>