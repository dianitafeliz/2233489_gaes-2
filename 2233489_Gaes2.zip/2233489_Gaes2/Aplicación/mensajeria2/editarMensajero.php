<?php

include("conexion.php");

if (isset($_GET['documento'])) {
    $documento = $_GET['documento'];
    $query = "SELECT * FROM usuarios WHERE documento = $documento";
    $result = mysqli_query($conexion, $query);

    if (mysqli_num_rows($result) == 1) {
       $row = mysqli_fetch_array($result);
       $documento = $row['documento'];
       $nombre = $row['nombre'];
       $apellido = $row['apellido'];
       $correo = $row['correo'];
       $direccion = $row['direccion'];
       $telefono = $row['telefono'];
       $password = $row['password'];
    }

    if (isset($_POST['update'])){
        $documento =$_GET['documento'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $correo = $_POST['correo'];
        $direccion = $_POST['direccion'];
        $telefono = $_POST['telefono'];
        $password = $_POST['password'];


        $query = "UPDATE usuarios set  documento='$documento',nombre='$nombre', apellido ='$apellido', correo='$correo', direccion='$direccion', telefono='$telefono', id_rol='2', password='$password' WHERE documento = $documento";
        mysqli_query($conexion, $query);
        header("Location:Mensajeros.php");
    }

}?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>editar cliente</title>
</head>
<body>
<div class="container p-4">
    <div class="row">
<div class="col-md-4 mx-auto">
    <div class="card card-body">
        <div class="card card-header">EDITAR MENSAJEROS</div>
    <form action="editarMensajero.php?documento=<?php echo $_GET['documento'];?>" method="POST">
    
    <div class="form-group">
        <input type="text" name="documento" value="<?php echo $documento?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="nombre" value="<?php echo $nombre?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="apellido" value="<?php echo $apellido?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="correo" value="<?php echo $correo?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="direccion" value="<?php echo $direccion?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="telefono" value="<?php echo $telefono?>" class="form-control">
    </div>

    <div class="form-group">
        <input type="text" name="password" value="<?php echo $password?>" class="form-control">
    </div>

    <br><button onclick="return alert ('Usuario editado con exito')" class="btn btn-success" name="update">
    Actualizar
    </button>
    </form>
    </div>
</div>

    
    </div>
</div>

</body>
</html>