<?php
//solo conectará a la base de datos
$servidor = "localhost";
$usuario = "root";
$contraseña = "";
$baseDatos = "mensajeria";
$conexion = mysqli_connect($servidor, $usuario, $contraseña,$baseDatos);

if ($conexion ->connect_errno) {
    echo "Error de la conexión de la base de datos" .$conexion ->connect_error;
    exit();
}else{
    
}

?>