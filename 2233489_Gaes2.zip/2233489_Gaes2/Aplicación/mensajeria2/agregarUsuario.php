<?php

require "conexion.php";


$documento = $_POST["documento"];
$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$correo = $_POST["correo"];
$direccion = $_POST["direccion"];
$telefono = $_POST["telefono"];
$rol = $_POST["rol"];
$password = $_POST["password"];


echo $documento."<br>";
echo $nombre."<br>";
echo $apellido."<br>";
echo $correo."<br>";
echo $direccion."<br>";
echo $telefono."<br>";
echo $rol."<br>";
echo $password."<br>";

$insertar = ("insert into usuarios values ('$documento','$nombre', '$apellido', '$correo', 
'$direccion','$telefono','$rol', '$password')");
// estamos ejecutando el query para saber si se conecta a la base de datos
$query = mysqli_query($conexion, $insertar);

//if para saber si se conectó

if ($query) {
    $_SESSION['message'] = 'Usuario Registrado';
    $_SESSION['message_type'] = 'danger';
    header("Location: index.php");
    # code...
}else{
    echo "conexion incorrecta";
}

// ahora se linkea el archivo de la conexionSQL

?>